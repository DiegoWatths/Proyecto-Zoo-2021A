package zoo_watths;

public class Ave extends Animal {
	
	public Ave(String Nombre, String Habitat, String Comida) {
		super(Nombre, Habitat, Comida);
	}
	
	@Override
	public void Definir() {
		System.out.println("\n\nEste animal es una Ave.");
	}
}
