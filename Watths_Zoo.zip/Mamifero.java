package zoo_watths;

public class Mamifero extends Animal {
	
	public Mamifero (String Nombre, String Habitat, String Comida) {
		super(Nombre, Habitat, Comida);
	}
	
	@Override
	public void Definir() {
		System.out.println("\n\nEste animal es un Mamífero.");
	}
}
