package zoo_watths;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Bienvenido a esta aplicación de un zoológico, el cual tiene mamiferos, aves y reptiles, según el siguiente menú seleccione la clase da animal a añadir:");
		Scanner entrada=new Scanner(System.in);
		int bucle=1, repetir=0;
		int i=0;
		String Nombre1[]= new String[10];
		String Habitat1[]=new String[10];
		String Comida1[]=new String[10];
		do {
			System.out.println("\n1.- Mamíferos" + "\n2.- Aves" + "\n3.- Reptiles" + "\n4.- Ver lista de animales" + "\n5.- Salir" + "\n¿Su opción?:");
			int elección=entrada.nextInt();
			switch(elección) {
			case 1: while(i<=9) {
				Animal nuevo=new Mamifero("","",""); //<- Instanciar Mamifero en blanco
				System.out.println("\n\n¿Qué nombre recibe el mamifero?: ");
				nuevo.setNombre(entrada.nextLine()); //<- Uso de los setters
				Nombre1[i]=entrada.nextLine(); //<- Almacenar en un array
				System.out.println("\nEntendido\n" + "¿En qué tipo de habitat vive?: ");
				nuevo.setHabitat(entrada.nextLine());
				Habitat1[i]=entrada.nextLine();
				System.out.println("\nPerfecto\n" + "¿Cómo se alimenta?: ");
				nuevo.setComida(entrada.nextLine());
				Comida1[i]=entrada.nextLine();
				System.out.println("\nFinalmente, ¿es el mamifero introducido nocturno o diurno?: ");
				String horario_nuevo=entrada.nextLine();
				if((horario_nuevo.equals("Nocturno"))||(horario_nuevo.equals("nocturno"))){ //Deteminar si el animal es nocturno
					nuevo.Nocturno=true;}
				nuevo.Definir(); //<- Método abstacto
				System.out.println("Su nombre es " + nuevo.getNombre(Nombre1[i]) + ", vive en un habitat " + nuevo.getHabitat(Habitat1[i]) + ", este se alimenta de " + nuevo.getComida(Comida1[i]));
				if(nuevo.Nocturno){
					System.out.println("y es un mamifero nocturno.");
				}else {System.out.println("y es un mamifero diurno.");}
				i++;
				System.out.println("¿Desea introducir otro mamífero? (Sí=0/No=1)"); //Regresar a línea 18
				repetir=entrada.nextInt();
				if(repetir==1) {
					break;
				}
			}
				break;
			case 2: while(i<=9) {
				Animal nuevo=new Ave("","",""); //<- Instanciar Ave en blanco
				System.out.println("\n\n¿Qué nombre recibe la ave?: ");
				nuevo.setNombre(entrada.nextLine());
				Nombre1[i]=entrada.nextLine();
				System.out.println("\nEntendido\n" + "¿En qué tipo de habitat vive?: ");
				nuevo.setHabitat(entrada.nextLine());
				Habitat1[i]=entrada.nextLine();
				System.out.println("\nPerfecto\n" + "¿Cómo se alimenta?: ");
				nuevo.setComida(entrada.nextLine());
				Comida1[i]=entrada.nextLine();
				System.out.println("\nFinalmente, ¿es la ave introducida nocturna o diurna?: ");
				String horario_nuevo=entrada.nextLine();
				if((horario_nuevo.equals("Nocturna"))||(horario_nuevo.equals("nocturna"))){
					nuevo.Nocturno=true;}
				nuevo.Definir();
				System.out.println("Su nombre es " + nuevo.getNombre(Nombre1[i]) + ", vive en un habitat " + nuevo.getHabitat(Habitat1[i]) + ", este se alimenta de " + nuevo.getComida(Comida1[i]));
				if(nuevo.Nocturno){
					System.out.println("y es una ave nocturna.");
				}else {System.out.println("y es una ave diurna.");}
				i++;
				System.out.println("¿Desea introducir otra ave? (Sí=0/No=1)");
				repetir=entrada.nextInt();
				if(repetir==1) {
					break;
				}
			}
				break;
			case 3: while(i<=9) {
				Animal nuevo=new Reptil("","",""); //<- Instanciar en blanco
				System.out.println("\n\n¿Qué nombre recibe el reptil?: ");
				nuevo.setNombre(entrada.nextLine());
				Nombre1[i]=entrada.nextLine(); 
				System.out.println("\nEntendido\n" + "¿En qué tipo de habitat vive?: ");
				nuevo.setHabitat(entrada.nextLine());
				Habitat1[i]=entrada.nextLine();
				System.out.println("\nPerfecto\n" + "¿Cómo se alimenta?: ");
				nuevo.setComida(entrada.nextLine());
				Comida1[i]=entrada.nextLine();
				System.out.println("\nFinalmente, ¿es el reptil introducido nocturno o diurno?: ");
				String horario_nuevo=entrada.nextLine();
				if((horario_nuevo.equals("Nocturno"))||(horario_nuevo.equals("nocturno"))){
					nuevo.Nocturno=true;}
				nuevo.Definir();
				System.out.println("Su nombre es " + nuevo.getNombre(Nombre1[i]) + ", vive en un habitat " + nuevo.getHabitat(Habitat1[i]) + ", este se alimenta de " + nuevo.getComida(Comida1[i]));
				if(nuevo.Nocturno){
					System.out.println("y es un reptil nocturno.");
				}else {System.out.println("y es un reptil diurno.");}
				i++;
				System.out.println("¿Desea introducir otro reptil? (Sí=0/No=1)");
				repetir=entrada.nextInt();
				if(repetir==1) {
					break;
				}
			}
				break;
			case 4: System.out.println("Nombre | Habitat | Comida");
				for(int j=0; j<10; j++) {
				System.out.println(Nombre1[j] + "|" + Habitat1[j] + "|" + Comida1[j]);
			}
				break;
			case 5: break;
				default: System.out.println("Opción no soportada. Ingrese una opción del menú");
					break;
			}
			if(elección!=5) {
			System.out.println("¿Desea regresar al menú? (Sí=0/No=1): ");
			bucle=entrada.nextInt();
			}
		}while(bucle==0);
		System.out.println("¡Que tenga un buen día!");
	}

}
