package zoo_watths;

public abstract class Animal {
	private String Nombre;
	private String Habitat;
	private String Comida;
	public boolean Nocturno;
	
	public Animal(String Nombre,String Habitat, String Comida) {
		this.Nombre=Nombre;
		this.Habitat=Habitat;
		this.Comida=Comida;
		Nocturno=false;
	}
	public abstract void Definir();
	
	public void setHabitat(String Habitat) {
		this.Habitat=Habitat;
	}
	public void setComida(String Comida) {
		this.Comida=Comida;
	}
	public void setNombre(String Nombre) {
		this.Nombre=Nombre;
	}
	public String getHabitat(String Habitat) {
		return Habitat;
	}
	public String getComida(String Comida) {
		return Comida;
	}
	public String getNombre(String Nombre) {
		return Nombre;
	}
}
