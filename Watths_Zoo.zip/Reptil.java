package zoo_watths;

public class Reptil extends Animal{
	
	public Reptil (String Nombre, String Habitat, String Comida) {
		super(Nombre, Habitat, Comida);
	}
	
	@Override
	public void Definir() {
		System.out.print("\n\nEste animal es un Reptil.");
	}
}
